<nav class="navbar navbar-expand-xl navbar-dark  bg-light">
  <div class="container-fluid">
  <div class="toggle-button">
  <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#menu01" aria-controls="menu01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
</div>
</div>
</nav>
<div class="topHeader">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-6 col-lg-4">
        <form action="#" method="POST" id="menuSearch">
            <input type="text" class="form-control" id="searchInp" placeholder="Search Photos, products, Pros & More...">
            <button type="submit" class="topSearch"><i class="fa fa-search"></i></button>
        </form>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-8" style="padding-right:0">
        <ul class="topMenu">
          <li><a href="../about.php">About Us </a></li>
          <li><a href="../contact.php">Contact Us</a></li>
          <li><a href="#">Blog</a></li>
          <li><a href="#" data-toggle="modal" data-target="#enteringViewpoint"><i class="fa fa-user"></i> Sign In</a></li>
          <!-- <li class="nav-item dropdown position-static2">
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false"><i class="fas fa-heart"></i></a>
              <div class="dropdown-menu" >
                <table width="100%" border="0" cellspacing="5" cellpadding="5">
                  <tr>
                    <td style="background: #2e2e38;"><i>No order yet added</i> &#128530; !</td>
                  </tr>
                </table>
              </div>
          </li> -->
          <li class="nav-item dropdown position-static2" id="menuWhislist">
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false"><i class="fas fa-heart"></i></a>
              <div class="dropdown-menu" id="menuWhislist_dropdown">
                <table width="100%" border="0" cellspacing="5" cellpadding="5">
                  <tr>
                    <td width="80"><img src="assets/images/dinning-table.png" class="img-responsive"></td>
                    <td>
                      <table width="100%">
                        <tr><td><span><a href="../productDetails.php">Dining Table</a></span></td></tr>
                        <tr><td><a href="../cart.php" class="cartMove">Move to cart</a></td></tr>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td><img src="assets/images/light.png" class="img-responsive"></td>
                    <td>
                      <table width="100%">
                        <tr><td><span><a href="../productDetails.php">22" Table Lamp - Whiteray Hurricane Outdoor Metal Lighting</a></span></td></tr>
                        <tr><td><a href="../cart.php" class="cartMove">Move to cart</a></td></tr>
                      </table>
                    </td>
                  </tr>
                  <tr>
                    <td width="80"><img src="assets/images/dinning-table.png" class="img-responsive"></td>
                    <td>
                      <table width="100%">
                        <tr><td><span><a href="../productDetails.php">Dining Table</a></span></td></tr>
                        <tr><td><a href="../cart.php" class="cartMove">Move to cart</a></td></tr>
                      </table>
                    </td>
                  </tr>
                </table>
              </div>
          </li>
          <!-- <li><a href="cart.php"><i class="far fa-shopping-cart"></i></a></li> -->
          <li class="nav-item"><a class="nav-link" href="cart.php"><i class="far fa-shopping-cart"></i> <span class="badge badge-danger">0</span></a></li>
          <li class="nav-item dropdown position-static2" id="menuProfile2">
            <a class="nav-link" href="#" class="menuItem" style="font-size:16px"><i class="fas fa-user-circle"></i> Hi Dheera,</a>
            <div class="dropdown-menu" >
                <a class="dropdown-item" href="../editprofile.php">Edit Profile</a>
                <a class="dropdown-item" href="../myorders.php">View Orders</a>
                <a class="dropdown-item" href="../login.php">Sign Out</a>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>