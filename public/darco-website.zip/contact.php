<?php include('common/header.php') ?>

<div class="page-header">
    <div class="container d-flex flex-column align-items-center">
        <h2 class="mt-4">Contact Us</h2>
    </div>
</div>
    <div class="container mt-5 mb-5">
        <h3>Contact Information</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut</p>
        <hr>
        <div class="row">
            <div class="col-sm-5 text-left">
                <table width="100%" id="contactID">
                    <tr><td><i class="fal fa-envelope-open-text"></i></td><td><h6 class="text_blue">Email Address</h6> admin@darco.com<br> contact@darco.com </td></tr>
                    <tr><td><i class="fal fa-phone-rotary"></i></td><td><h6 class="text_blue">Contact Number</h6> 00 000 00000 <br> 19 485 67667</td>
                    <tr><td><i class="fal fa-map-marker-alt"></i></td><td><h6 class="text_blue">Location</h6> Lawrence, NY 11345, USA </td></tr>
                </table>
            </div>
            <div class="col-sm-7">
                <form action="#">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" name="username" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Email address</label>
                        <input type="email" name="emailID" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="tel" name="phone" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Message</label>
                        <textarea class="form-control"></textarea>
                    </div>
                </form>
            </div>
        </div>
    </div>




<?php include('common/footer.php') ?>
