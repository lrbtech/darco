<?php include('common/header.php') ?>

<div class="page-header">
	<div class="container d-flex flex-column align-items-center">
		<h2 class="mt-4">Your Shopping Cart</h2>
	</div>
</div>

<div class="container mt-5 mb-5" id="Shoppingcart">
    <div class="row">
      <div class="col-md-7 col-lg-8">
		<table width="100%" border="0" id="orderItem" class="text-left">
    <thead>
      <tr>
        <th colspan="2">Ordered Items</th>
        <th width="150" class="text-right">Price</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><img src="assets/images/sofa.png"></td>
        <td>
          <table class="innerTbl" width="100%">
            <tr>
              <td colspan="4"><h3 class="cart-product-title text-left"><a href="productDetails.php">Urban Basics Morto 5 Seater RHS Fabric L Shape Sofa Set (Dark Grey- Light Grey)</a></h3></td>
            </tr>
            <tr>
              <td><span class="text-success fwt-600">In Stock</span> <br> <span>Deliver by 2 - 3 days</span></td>
              <td><select class="form-control" style="padding: 0 0px 0 5px; width: 50px;"><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option></select></td>
              <td>
                <a href="#" class="btn btn-default btn-sm" data-toggle="tooltip" data-placement="top" title="Add to whislist"><i class="far fa-heart"></i></a> <a href="#" class="btn btn-default btn-sm" data-toggle="tooltip" data-placement="top" title="Remove from list"><i class="far fa-trash"></i></a>
              </td>
            </tr>
          </table>
          </td>
        <td class="orderPrice">15,000</td>
      </tr>
      <tr>
        <td><img src="assets/images/light.png"></td>
        <td>
          <table class="innerTbl" width="100%">
            <tr>
              <td colspan="4"><h3 class="cart-product-title text-left"><a href="productDetails.php">U22" Table Lamp - Whiteray Hurricane Outdoor Metal Lighting/Exterior Wall Light Lamp/Wall Gate Light for Home Decor (Bulb Not Included) (Pack of 1)</a></h3></td>
            </tr>
            <tr>
              <td><span class="text-success fwt-600">In Stock</span> <br> <span>Deliver by 2 - 3 days</span></td>
              <td><select class="form-control" style="padding: 0 0px 0 5px; width: 50px;"><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option></select></td>
              <td>
                <a href="#" class="btn btn-default btn-sm" data-toggle="tooltip" data-placement="top" title="Add to whislist"><i class="far fa-heart"></i></a> <a href="#" class="btn btn-default btn-sm" data-toggle="tooltip" data-placement="top" title="Remove from list"><i class="far fa-trash"></i></a>
              </td>
            </tr>
          </table>
          </td>
        <td class="orderPrice">1,499</td>
      </tr>
      <tr class="disabled">
        <td><img src="assets/images/table2.jpg"></td>
        <td>
          <table class="innerTbl" width="100%">
            <tr>
              <td colspan="4"><h3 class="cart-product-title text-left"><a href="productDetails.php">FURNITURE HUB Coffee Table Side Table for Home Table | Living Room Sofa Center Stylish Coffee Table for Home Decor Furniture | Coffee Table with Storage Engineered Wood Light Weight for Coffee Table</a></h3></td>
            </tr>
            <tr>
              <td colspan="3"><button class="btn btn-danger fwt-600" disabled>Out of Stock</button></td>
            </tr>
          </table>
          </td>
        <td class="orderPrice">1,499</td>
      </tr>
    </tbody>
    </table>
  </div>
  <div class="col-md-5 col-lg-4">
    <div class="card2 font-roboto">
      <h4 class="f18 colorBrown">Order Details</h4>
      <table border="0" cellspacing="5" cellpadding="5" width="100%" class="">
        <tbody>
          <tr><td>Subtotal</td><td class="text-right">₹ 16,999</td></tr>
          <tr><td>Shipping</td><td class="text-right">₹ 500</td></tr>
          <tr><td>Tax</td><td class="text-right">₹ 500</td></tr>
        </tbody>
        <tfoot>
          <tr>
            <th>Total</th><th class="text-right">₹ 17,999</th>
          </tr>
        </tfoot>
      </table><br><br>
      <a href="checkout.php" class="btn btn-warning btn-block btn-md">Proceed to checkout</a>
    </div>
  </div>
  <div>
    
  </div>
</div>
	</div>
</div>

<?php include('common/footer.php') ?>