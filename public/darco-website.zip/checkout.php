<?php include('common/header.php') ?>

<div class="page-header">
  <div class="container d-flex flex-column align-items-center">
    <h2 class="mt-4">Checkout</h2>
  </div>
</div>


<div class="container mt-5 mb-5" id="Shoppingcart">

<div class="">
  <div class="row">
    <div class="col-sm-2 col-md-2 col-lg-3"></div>
    <div class="col-sm-8 col-md-8 col-lg-6">
      <div id="coupon" class="text-center f18">
        Have a coupon? <a href="javascript:;" onclick="viewcoupon()">Click here to enter your code</a>
      </div> <br>
      <div class="checkout_coupon" style="display:none">
        <form action="#" method="POST">
          <h5 class="mb-4 fwt-400">If you have a coupon code, please apply it below.</h5>
          <div class="form-group">
            <input type="text" name="coupon" class="form-control" placeholder="Coupon Code">
          </div>
          <button class="btn btn-dark">Apply Coupon</button>
        </form>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-sm-7 col-md-8">
      <h5 class="title text_blue">Billing Details</h5> <br><br>
      <?php include('common/address.php') ?>

      <div class="row">
        <div class="col-sm-12">
          <div class="form-group">
            <label class="fwt-400"><input type="checkbox" name="shippingaddress"> Ship to a different address?</label>
          </div>
        </div>
      </div>
      <div id="viewShipAddress" style="display:none"><?php include('common/address.php') ?></div>
      <div class="row">
        <div class="col-sm-12">
          <div class="form-group">
            <label>Order Message</label>
            <textarea type="text" name="message" class="form-control"></textarea>
          </div>
        </div>
      </div>
    </div>


    <div class="col-sm-5 col-md-4">
      <h5 class="title text_blue">Your Order</h5>
      <hr> <br><br>
      <div class="orderDet">
      <table border="0" cellspacing="5" cellpadding="5" width="100%" class="font-roboto">
        <thead>
          <tr>
            <th width="1%"></th>
            <th>Product</th>
            <th>Subtotal</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td class="prodOrder">Urban Basics Morto 5 Seater RHS Fabric L Shape Sofa Set (Dark Grey- Light Grey)</td>
            <td class="text-right" width="30%">₹15,000</td>
          </tr>
          <tr>
            <td>2</td>
            <td class="prodOrder">U22" Table Lamp - Whiteray Hurricane Outdoor Metal Lighting/Exterior Wall Light Lamp/Wall Gate Light for Home Decor</td>
            <td class="text-right" width="30%">₹1,499</td>
          </tr>
          <tr><td colspan="3"><hr></td></tr>
          <tr><td colspan="2">Shipping</td><td class="text-right">₹500</td></tr>
          <tr><td colspan="2">Tax (5%)</td><td class="text-right">₹500</td></tr>
        </tbody>
        <tfoot>
          <tr>
            <th colspan="2">Total</th><th class="text-right">₹17,999</th>
          </tr>
        </tfoot>
      </table>
    </div>

    <br><br>

    <h5>Payment Method</h5>
    <hr><br>
    

    <div class="accordion" id="checkAccord">
    <div class="card3">
    <div class="card-header" id="headingOne">
      <a href="javascript:;" class="accordionHeading" data-toggle="collapse" data-target="#collapseOne">Credit / Debit Card</a>
    </div>
    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#checkAccord">
      <!-- collapse show -->
      <div class="card-body">
        <table width="100%" border="0" class="font-roboto">
          <tbody>
            <tr>
              <td><input type="radio" name="payMethod1" value="sbi"></td>
              <td>
                <span class="bankname fwt-600">SBI Bank Debit Card</span> <br> <i class="f12">Expires 01/2024</i>
              </td>
              <td width="30%">
                <div class="sbi cvvDetail mt-2" style="display:none">
                  <input type="text" name="cvvNum" class="form-control form-control-sm" placeholder="CVV No.">
                  <a href="javascript:;" data-toggle="tooltip" data-placement="top" title="Enter last 3 digit number"><i class="far fa-question-circle"></i></a>
                </div>
              </td>
            </tr>
            <tr>
              <td><input type="radio" name="payMethod1" value="yesbank"></td>
              <td>
                <span class="bankname fwt-600">YES Bank Credit Card</span> <br> <i class="f12">Expires 01/2024</i>
              </td>
              <td>
                <div class="yesbank cvvDetail mt-2" style="display:none">
                    <input type="text" name="cvvNum" class="form-control form-control-sm" placeholder="CVV No.">
                    <a href="javascript:;" data-toggle="tooltip" data-placement="top" title="Enter last 3 digit number"><i class="far fa-question-circle"></i></a>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="card3">
    <div class="card-header" id="headingTwo">
      <a href="javascript:;" class="accordionHeading" data-toggle="collapse" data-target="#collapseTwo">Netbanking</a>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#checkAccord">
      <div class="card-body">
        <table width="100%" border="0">
          <tr>
            <td><input type="radio" name="payMethod2" value=""></td>
            <td><span class="bankname fwt-600">State Bank of India</span></td>
            <td width="20%"><a href="javascript:;"><img src="assets/images/hdfc-logoicon.jpg" class="img-responsive" width=""></a></td>
          </tr>
          <tr>
            <td><input type="radio" name="payMethod2" value=""></td>
            <td><span class="bankname fwt-600">YES Bank</span></td>
            <td><a href="javascript:;"><img src="assets/images/yesbank-logoicon.jpg" class="img-responsive" width=""></a></td>
          </tr>
        </table>
      </div>
    </div>
  </div>
<div class="card3">
  <div class="card-header" id="headingThree">
      <a href="javascript:;" class="accordionHeading" data-toggle="collapse" data-target="#collapseThree">Cash on Delivery</a>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#checkAccord">
      <div class="card-body">
        Pay with cash upon delivery.
      </div>
    </div>
  </div>
</div> <br><br>

<a class="btn btn-dark btn-block f18" href="orderSummary.php">Place order</a>

    </div>
  </div>
</div>


</div>

<!-- CHECK OUT -->
<script type="text/javascript">
  $(document).ready(function() {
    $('input[name="payMethod1"]').click(function(){
       var val = $(this).attr("value");
          var target = $("." + val);
          $(".cvvDetail").not(target).hide();
          $(target).show();
    });
   

$("input[name=shippingaddress]:checkbox").click(function(event) {
    if ($(this).is(":checked")){
      $("#viewShipAddress").show();
    }
    else{
      $("#viewShipAddress").hide();
    }
  });

  });

   function viewcoupon(){ 
      $(".checkout_coupon").toggle();
    };
</script>

<?php include('common/footer.php') ?>