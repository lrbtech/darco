
<!-- Modal enteringViewpoint -->
<div class="modal fade" id="enteringViewpoint" tabindex="-1" role="dialog" aria-labelledby="enteringViewpointLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg  modal-dialog-centered modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">Choose who you are?</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-sm-6">
            <a href="individualDetails.php" class="style3" id="view1">
              <div class="card">
                <div class="card-title"><h4>Individual</h4></div>
                <div class="card-desc text-center">
                  <span id="img-icon"></span><br> <br>
                  <p>I am a owner of the property, selling the lands, homes, appliances, like etc.,</p>
                <div class="text-left">  
                </div>
              </div>
              <button type="button" class="btn btn-dark btn-md">Join us</button>
            </div>
          </a>
          </div>
          <div class="col-sm-6">
            <a href="professionalDetails.php" class="style3" id="view2">
            <div class="card">
              <div class="card-title"><h4>Professional</h4></div>
              <div class="card-desc text-center">
                <span id="img-icon2"></span><br> <br>
                <p>We offer home improvement service or sell home products, lands.</p>
                <div class="text-left">
              </div>
              </div>
              <button type="button" class="btn btn-dark btn-md">Join us</button>
            </div>
          </a>
          </div>
        </div>
      </div>
      <!-- <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div> -->
    </div>
  </div>
</div>