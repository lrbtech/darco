<footer class="footer bg-dark">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-sm-6">
                                <h4 class="footer-title">Contact Info</h4>
                                <ul class="contact-info">
                                    <li>
                                        <span class="contact-info-label">Address:</span>123 Street Name, City, Country
                                    </li>
                                    <li>
                                        <span class="contact-info-label">Phone:</span><a href="tel:">(123)456-7890</a>
                                    </li>
                                    <li>
                                        <span class="contact-info-label">Email:</span> <a href="mailto:mail@example.com">mail@example.com</a>
                                    </li>
                                </ul>
                                <div class="social-icons">
                                    <a href="#" class="social-icon social-facebook icon-facebook" target="_blank" title="Facebook"></a>
                                    <a href="#" class="social-icon social-twitter icon-twitter" target="_blank" title="Twitter"></a>
                                    <a href="#" class="social-icon social-instagram icon-instagram" target="_blank" title="Instagram"></a>
                                </div>
                        </div>
                        <!-- End .col-lg-3 -->

                        <div class="col-lg-4 col-sm-6">
                                <h4 class="footer-title">Customer Service</h4>
                                <ul class="links">
                                    <li><a href="#">Help &amp; FAQs</a></li>
                                    <li><a href="myorders.php">Order Tracking</a></li>
                                    <li><a href="editprofile.php">My Account</a></li>
                                    <li><a href="#">Careers</a></li>
                                    <li><a href="about.php">About Us</a></li>
                                    <li><a href="#">Privacy</a></li>
                                </ul>
                        </div>

                        <div class="col-lg-4 col-sm-6">
                            <div class="footer-newsletter">
                                <h4 class="widget-title">Subscribe newsletter</h4>
                                <p>Get all the latest information on events, sales and offers. Sign up for newsletter:
                                </p>
                                <form action="#" class="mb-0">
                                  <div class="form-group">
                                    <input type="email" class="form-control m-b-3" placeholder="Email address" required="">
                                  </div>

                                    <input type="submit" class="btn btn-primary shadow-none" value="Subscribe">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            <div class="container">
                <div class="footer-bottom">
                    <div class="container">
                        <div class="text-center">
                            <span class="footer-copyright">© DARCO 2022. All Rights Reserved</span>
                        </div>
                    </div>
                </div>
                <!-- End .footer-bottom -->
            </div>
            <!-- End .container -->
        </footer>


    <script src="../assets/js/jquery.slim.min.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
 <script type="text/javascript" src="../assets/js/jquery.min.js"></script> 
<script>

    // Banner
$(function(){
let slideIndex = 0;
showSlides();


function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
   for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  slides[slideIndex-1].style.display = "block";  
  setTimeout(showSlides, 5000); 
};
})


// Comment box


</script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>
  
  </body>
</html>