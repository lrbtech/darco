<?php include('common/header.php') ?>




<div class="container mt-5 mb-5" id="prodDetViews">
	<div class="card text-left">
        <div class="row">
          <div class="preview col-md-4">
            <div class="thumbnail-container mt-5">
                <img class="drift-demo-trigger img-responsive" data-zoom="assets/images/light.png" src="assets/images/light.png">
            </div>
          </div>
          <div class="details col-md-8">
            <h3 class="product-title mt-3">22" Table Lamp - Whiteray Hurricane Outdoor Metal Lighting/Exterior Wall Light Lamp/Wall Gate Light for Home Decor (Bulb Not Included) (Pack of 1)</h3>
            <div class="rating">
              <div class="stars">
                <span class="fa fa-star checked"></span>
                <span class="fa fa-star checked"></span>
                <span class="fa fa-star checked"></span>
                <span class="fa fa-star"></span>
                <span class="fa fa-star"></span>
                <span class="review-no" style="color:#2e2e38">41 reviews</span>
              </div>
              
            </div><br>

            <table width="auto" border="0" cellspacing="5" cellpadding="5" id="pricingTable">
              <tbody>
                <tr><td>M.R.P.</td ><td> : </td><td class="font-roboto"><del>₹4,490.00</del></td></tr>
                <tr><td>Deal of the Day</td><td> : </td><td><span class="price font-mon">₹ 1,399.00</span> <br> <small>Ends in 2 days</small></td></tr>
                <tr><td>You Save</td><td> : </td><td class="font-roboto">₹3,091.00 (69%) <br><small>Inclusive of all taxes</small></td></tr>
              </tbody>
              </table><br>

            <div class="view-product__quantity-alert mbm text-bold mts">Only 8 left!</div>
            
            <div class="row mt-2 mb-2">
              <div class="col-4">
                <select class="form-control" style="height:50px"><option>QTY</option><option>1</option><option>2</option><option>3</option></select>
              </div>
              <div class="col-6">
                <a href="cart.php" class="btn btn-success btn-block"><i class="far fa-cart-arrow-down"></i> Add to Cart</a>
              </div>
            </div><br>
            

            <table width="100%" border="0" id="optiontoPay" class="fwt-600">
              <tr>
                <td><img src="assets/images/cod.png" width="45px"><br><span>Cash on Delivery</span></td>
                <td><img src="assets/images/exchange.png" width="45px"><br><span>10 Days Replacement</span></td>
                <td><img src="assets/images/warranty.png" width="45px"><br><span>Assured Product</span></td>
              </tr>
            </table><br>
            <p><i class="fas fa-shipping-fast"></i>&nbsp; Ready to ship to the  in 1-3 days</p>

          </div>
        </div> <br><br>

    </div>

    <hr>

    <div class="card2">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" id="tab1" data-toggle="tab" href="#prod_desc" role="tab">Product Description</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="tab2" data-toggle="tab" href="#prodspeci" role="tab">Product Specifications</a>
  </li>
</ul>
<div class="tab-content f14" id="myTabContent">
  <div class="tab-pane fade show active" id="prod_desc" role="tabpanel">
    <p>This unique Dragonfly Table Lamp has been handcrafted using methods first developed by Louis Comfort Tiffany. The shade contains pieces of stained glass, each hand-cut and wrapped in fine copper foil, in rich tones of blue. Yellow dragonflies accent the shade with red and green jeweled accents. The base has an elegant bronze finish.</p>
    <ul><li>Base with its bronze finish makes for an aged quality look</li><li>The lamp is 23" tall X 16" in width</li><li>Easy to use 2 pull chains for on/off lighting.</li><li>Uses two 60-Watt bulbs and can use CFL or LED bulbs.</li></ul>
  </div>
  <div class="tab-pane fade" id="prodspeci" role="tabpanel">
    <table border="1" cellspacing="2" cellpadding="2">
      <tr><td>Product ID</td><td>001</td></tr>
      <tr><td>Manufactured By</td><td>xxx Company</td></tr>
      <tr><td>Sold By</td><td>XXX User</td></tr>
      <tr><td>Size/Weight</td><td>W 16" / D 16" / H 23" / 10 lb.</td></tr>
      <tr><td>Materials</td><td>Glass, Metal</td></tr>
      <tr><td>Assembly Required</td><td>Yes</td></tr>
      <tr><td>Category</td><td>Table Lamps</td></tr>
      <tr><td>Style</td><td>Victorian</td></tr>
    </table>
  </div>
</div>

<hr>

 <div class="row">
            <div class="col">
               <div class="bbb_main_container">
                <div class="bbb_viewed_title_container">
                    <h3 class="">Related Products</h3>
                    <div class="bbb_viewed_nav_container text-right">
                        <a href="javascript:;" class="bbb_viewed_nav bbb_viewed_prev"><i class="fas fa-chevron-left"></i></a>
                        <a href="javascript:;" class="bbb_viewed_nav bbb_viewed_next"><i class="fas fa-chevron-right"></i></a>
                    </div>
                </div>
                <div class="bbb_viewed_slider_container">
                    <div class="owl-carousel owl-theme bbb_viewed_slider">
                        <div class="owl-item">
                            <div class="bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="bbb_viewed_image"><img src="assets/images/lights/8.jpg" alt=""></div>
                                <div class="bbb_viewed_content text-center">
                                    <div class="bbb_viewed_name"><a href="#">US DZIRE - THE BRAND OF LIFESTYLE ® 406 Hanging Lamp Electric Antique Wooden Ceiling Lights with Gold Bulb Pendant Lamp Night Lamp Living Room </a></div>
                                </div> 
                            </div>
                        </div>
                        <div class="owl-item">
                            <div class="bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="bbb_viewed_image"><img src="assets/images/lights/2.png" alt=""></div>
                                <div class="bbb_viewed_content text-center">
                                    <div class="bbb_viewed_name"><a href="#">22" Table Lamp - Whiteray Hurricane Outdoor Metal Lighting</a></div>
                                </div> 
                            </div>
                        </div>
                        <div class="owl-item">
                            <div class="bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="bbb_viewed_image"><img src="assets/images/lights/3.png" alt=""></div>
                                <div class="bbb_viewed_content text-center">
                                    <div class="bbb_viewed_name"><a href="#">22" Table Lamp - Whiteray Hurricane Outdoor Metal Lighting</a></div>
                                </div> 
                            </div>
                        </div>
                        <div class="owl-item">
                            <div class="bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="bbb_viewed_image"><img src="assets/images/lights/4.png" alt=""></div>
                                <div class="bbb_viewed_content text-center">
                                    <div class="bbb_viewed_name"><a href="#">22" Table Lamp - Whiteray Hurricane Outdoor Metal Lighting</a></div>
                                </div> 
                            </div>
                        </div>
                        <div class="owl-item">
                            <div class="bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="bbb_viewed_image"><img src="assets/images/lights/5.jpg" alt=""></div>
                                <div class="bbb_viewed_content text-center">
                                    <div class="bbb_viewed_name"><a href="#">US DZIRE - THE BRAND OF LIFESTYLE 408 Hanging Lamp Electric Antique Wooden Ceiling Lights</a></div>
                                </div> 
                            </div>
                        </div>
                        <div class="owl-item">
                            <div class="bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="bbb_viewed_image"><img src="assets/images/lights/6.jpg" class="img-responsive" alt=""></div>
                                <div class="bbb_viewed_content text-center">
                                    <div class="bbb_viewed_name"><a href="#">OURVIC 40 watts Ceiling Light, Black, Cage, Round Cluster</a></div>
                                </div> 
                            </div>
                        </div>
                        <div class="owl-item">
                            <div class="bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="bbb_viewed_image"><img src="assets/images/lights/7.jpg" alt=""></div>
                                <div class="bbb_viewed_content text-center">
                                    <div class="bbb_viewed_name"><a href="#">Best India Cane Handicraft Hanging Lamps for Livingroom Home Decoration Cane Lamp Shades Hanging Bamboo Lamp Lights Balcony</a></div>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>
               </div> 
            </div>
        </div>
<hr>
<h5>Recently Viewed</h5>
        <div class="row">
            <div class="col-3 col-lg-2"><a href="productDetails.php"><img src="assets/images/lights/1.png" class="img-responsive" alt=""></a></div>
            <div class="col-3 col-lg-2"><a href="productDetails.php"><img src="assets/images/sofa.png" class="img-responsive" alt=""></a></div>
            <div class="col-3 col-lg-2"><a href="productDetails.php"><img src="assets/images/light.png" class="img-responsive" alt=""></a></div>
            <div class="col-3 col-lg-2"><a href="productDetails.php"><img src="assets/images/bed.jpg" class="img-responsive" alt=""></a></div>
            <div class="col-3 col-lg-2"><a href="productDetails.php"><img src="assets/images/chair.jpg" class="img-responsive" alt=""></a></div>
        </div>
    </div>
  </div>

 <script src='assets/js/Drift.min.js'></script>  
<script type="text/javascript">
    new Drift(document.querySelector('.drift-demo-trigger'), {
  paneContainer: document.querySelector('.details'),
  inlinePane: 769,
  inlineOffsetY: -85,
  containInline: true,
  hoverBoundingBox: true
});

</script>

<?php include('common/footer.php') ?>