<?php include('common/header.php') ?>

<div class="page-header">
	<div class="container d-flex flex-column align-items-center">
		<h2 class="mt-4">Your Orders</h2>
		<p>You may see the orders which you recently buy..</p>
	</div>
</div>

<div class="container mt-5 mb-5">
	<div class="card2">
		<table width="100%" border="0" class="font-roboto text-left" id="orderItem">
    <thead>
      <tr>
        <th colspan="2">Order placed</th>
        <th width="200">Shipped to</th>
        <th width="200">Status</th>
        <th width="150">Total (Rs)</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><img src="assets/images/sofa.png"></td>
        <td>
          <a href="productDetails.php">Solimo Tulip Leatherette 3 Seater Sofa (Beige)</a><br>
        </td>
        <td> <span>Dheera</span></td>
        <td>Expected delivery by 12-09-2022</td>
        <td><h5>15,000</h5></td>
      </tr>
      <tr>
        <td><img src="assets/images/table2.jpg"></td>
        <td><a href="productDetails.php">Dime Store Wooden Iron Round Table Coffee Table for Living Room Center Table Home Office </a></td>
        <td> <span>John</span></td>
        <td>Delivered on 01-01-2022</td>
        <td><h5>23,000</h5></td>
      </tr>
    </tbody>
    </table>
	</div>
</div>

<?php include('common/footer.php') ?>