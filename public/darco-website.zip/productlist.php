<?php include('common/header.php') ?>


<div class="container mt-5 mb-5">
    <div class="card12">
	 <div class="row">
            <div class="col">
               <div class="bbb_main_container">
                <div class="bbb_viewed_title_container">
                    <h3 class="bbb_viewed_title">Lamp lights</h3>
                </div>
                 <div class="bbb_viewed_slider_container">
                    <div class="owl-carousel owl-theme bbb_viewed_slider">
                        <div class="owl-item">
                            <div class="bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="bbb_viewed_image"><img src="assets/images/lights/8.jpg" alt=""></div>
                                <div class="bbb_viewed_content text-center">
                                    <div class="bbb_viewed_name"><a href="productDetails.php">US DZIRE - THE BRAND OF LIFESTYLE ® 406 Hanging Lamp Electric Antique Wooden Ceiling Lights with Gold Bulb Pendant Lamp Night Lamp Living Room </a></div>
                                </div> 
                            </div>
                        </div>
                        <div class="owl-item">
                            <div class="bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="bbb_viewed_image"><img src="assets/images/lights/2.png" alt=""></div>
                                <div class="bbb_viewed_content text-center">
                                    <div class="bbb_viewed_name"><a href="productDetails.php">22" Table Lamp - Whiteray Hurricane Outdoor Metal Lighting</a></div>
                                </div> 
                            </div>
                        </div>
                        <div class="owl-item">
                            <div class="bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="bbb_viewed_image"><img src="assets/images/lights/3.png" alt=""></div>
                                <div class="bbb_viewed_content text-center">
                                    <div class="bbb_viewed_name"><a href="productDetails.php">22" Table Lamp - Whiteray Hurricane Outdoor Metal Lighting</a></div>
                                </div> 
                            </div>
                        </div>
                        <div class="owl-item">
                            <div class="bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="bbb_viewed_image"><img src="assets/images/lights/4.png" alt=""></div>
                                <div class="bbb_viewed_content text-center">
                                    <div class="bbb_viewed_name"><a href="productDetails.php">22" Table Lamp - Whiteray Hurricane Outdoor Metal Lighting</a></div>
                                </div> 
                            </div>
                        </div>
                        <div class="owl-item">
                            <div class="bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="bbb_viewed_image"><img src="assets/images/lights/5.jpg" alt=""></div>
                                <div class="bbb_viewed_content text-center">
                                    <div class="bbb_viewed_name"><a href="productDetails.php">US DZIRE - THE BRAND OF LIFESTYLE 408 Hanging Lamp Electric Antique Wooden Ceiling Lights</a></div>
                                </div> 
                            </div>
                        </div>
                        <div class="owl-item">
                            <div class="bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="bbb_viewed_image"><img src="assets/images/lights/6.jpg" alt=""></div>
                                <div class="bbb_viewed_content text-center">
                                    <div class="bbb_viewed_name"><a href="productDetails.php">OURVIC 40 watts Ceiling Light, Black, Cage, Round Cluster</a></div>
                                </div> 
                            </div>
                        </div>
                        <div class="owl-item">
                            <div class="bbb_viewed_item discount d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="bbb_viewed_image"><img src="assets/images/lights/7.jpg" alt=""></div>
                                <div class="bbb_viewed_content text-center">
                                    <div class="bbb_viewed_name"><a href="productDetails.php">Best India Cane Handicraft Hanging Lamps for Livingroom Home Decoration Cane Lamp Shades Hanging Bamboo Lamp Lights Balcony</a></div>
                                </div> 
                            </div>
                        </div>
                    </div>
                        <div class="bbb_viewed_nav_container text-center mt-5 mb-5">
                            <a href="javascript:;" class="bbb_viewed_nav bbb_viewed_prev"><i class="fas fa-chevron-left"></i></a>
                            <a href="javascript:;" class="bbb_viewed_nav bbb_viewed_next"><i class="fas fa-chevron-right"></i></a>
                        </div>
                </div>
               </div> 
            </div>
        </div>

        <div class="newsletter mt-3 mb-3">
            <h2>Sign Up and Get 25% Discount</h2>
            <p class="description">Get it first. Sign up for up-to-the-minute offers, sales and news.</p>
        </div>

        <h2 class="bbb_viewed_title">Celing Lights</h2>
        <div class="row prodCC">
            <div class="col-sm-6 col-md-3">
                <a href="productDetails.php">
                    <img src="assets/images/lights/1.png" class="img-responsive">
                    <span class="product-title">Wood finish (Dimmable led with remote control) Ceiling light</span>
                </a>
            </div>
            <div class="col-sm-6 col-md-3">
                <a href="productDetails.php">
                    <img src="assets/images/lights/2.png" class="img-responsive">
                    <span class="product-title">Ceiling lamp with 3 lamps, chrome-plated/opal white glass</span>
                </a>
            </div>
            <div class="col-sm-6 col-md-3">
                <a href="productDetails.php">
                    <img src="assets/images/lights/3.png" class="img-responsive">
                    <span class="product-title">Nights In June (Dimmable LED with Remote Control) Double Height Chandelier</span>
                </a>
            </div>
            <div class="col-sm-6 col-md-3">
                <a href="productDetails.php">
                    <img src="assets/images/lights/4.png" class="img-responsive">
                    <span class="product-title">Orange Tree Kyoto Dome Hanging Lamp</span>
                </a>
            </div>
            <div class="col-sm-6 col-md-3">
                <a href="productDetails.php">
                    <img src="assets/images/lights/9.jpg" class="img-responsive">
                    <span class="product-title">Lighting Hours - Voila - Decorative Wall Lamp for Living</span>
                </a>
            </div>
            <div class="col-sm-6 col-md-3">
                <a href="productDetails.php">
                    <img src="assets/images/lights/10.jpg" class="img-responsive">
                    <span class="product-title">Space Wall Mount Bedside Lamp for Bedroom, (Pack of 1) Dim Night Light for Night Reading</span>
                </a>
            </div>
            <div class="col-sm-6 col-md-3">
                <a href="productDetails.php">
                    <img src="assets/images/lights/11.jpg" class="img-responsive">
                    <span class="product-title">Craftter Wall Lamp for Living and Bed Room Light-Stainless Steel Base</span>
                </a>
            </div>
            <div class="col-sm-6 col-md-3">
                <a href="productDetails.php">
                    <img src="assets/images/lights/12.jpg" class="img-responsive">
                    <span class="product-title">ZOZAIN Tree Shape Pipe and Globe Wall Sconce Traditional Indoor Wall Light Lamp</span>
                </a>
            </div>
        </div>
    </div>

<div class="row mt-4 mb-4">
    <div class="col-sm-6">
        <div class="shortView">
            <div class="shortView_featuredimage" style="background-image:url(assets/images/2.png);"></div>
            <div class="shortView-content">
                <div class="shortView-title">Home Improvement </div>
                <div class="description mb-5">Your one-stop shop for all you need</div>
                <button type="button" class="btn btn-dark btn-sm">Show Now</button>
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="shortView">
            <div class="shortView_featuredimage" style="background-image:url(assets/images/3.png);"></div>
            <div class="shortView-content">
                <div class="shortView-title">Top Picks That Make The Space </div>
                <div class="description mb-5">Shop the versatile finds everyone loves</div>
                <button type="button" class="btn btn-dark btn-sm">Show Now</button>
            </div>
        </div>
    </div>
</div>



</div>






<?php include('common/footer.php') ?>