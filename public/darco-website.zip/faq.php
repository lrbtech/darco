<?php include('common/header.php') ?>

<div class="page-header">
    <div class="container d-flex flex-column align-items-center">
        <h2 class="mt-4">Frequently Asked Question</h2>
    </div>
</div>

<div class="container mt-5 mb-5">
  <div class="accordion" id="faqView">

    <div class="card3">
      <div class="card-header" id="headingOne"  data-toggle="collapse" data-target="#collapseOne">
        <a href="javascript:;" class="accordionHeading">How can I cancel my order?</a>
         <span class="accicon"><i class="fas fa-angle-down rotate-icon"></i></span>
      </div>
      <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#faqView">
        <div class="card-body">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
      </div>
    </div>

    <div class="card3">
      <div class="card-header" id="heading2"  data-toggle="collapse" data-target="#collapse2">
        <a href="javascript:;" class="accordionHeading">Why is my registration delayed?</a>
         <span class="accicon"><i class="fas fa-angle-down rotate-icon"></i></span>
      </div>
      <div id="collapse2" class="collapse" aria-labelledby="heading2" data-parent="#faqView">
        <div class="card-body">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
      </div>
    </div>

    <div class="card3">
      <div class="card-header" id="heading3"  data-toggle="collapse" data-target="#collapse3">
        <a href="javascript:;" class="accordionHeading">What do I need to buy products?</a>
         <span class="accicon"><i class="fas fa-angle-down rotate-icon"></i></span>
      </div>
      <div id="collapse3" class="collapse" aria-labelledby="heading3" data-parent="#faqView">
        <div class="card-body">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
      </div>
    </div>

    <div class="card3">
      <div class="card-header" id="heading4"  data-toggle="collapse" data-target="#collapse4">
        <a href="javascript:;" class="accordionHeading">How can I track an order?</a>
         <span class="accicon"><i class="fas fa-angle-down rotate-icon"></i></span>
      </div>
      <div id="collapse4" class="collapse" aria-labelledby="heading4" data-parent="#faqView">
        <div class="card-body">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
      </div>
    </div>

    <div class="card3">
      <div class="card-header" id="heading5"  data-toggle="collapse" data-target="#collapse5">
        <a href="javascript:;" class="accordionHeading">How can I get money back?</a>
         <span class="accicon"><i class="fas fa-angle-down rotate-icon"></i></span>
      </div>
      <div id="collapse5" class="collapse" aria-labelledby="heading5" data-parent="#faqView">
        <div class="card-body">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
      </div>
    </div>

  </div>
</div>
<?php include('common/footer.php') ?>