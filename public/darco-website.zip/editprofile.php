<?php include('common/header.php') ?>

<div class="page-header">
	<div class="container d-flex flex-column align-items-center">
		<h2 class="mt-4">My Account</h2>
	</div>
</div>

<section class="mt-5 mb-5">
<div class="container">
  <form>

  <div class="row" id="profileEditmode">
      <div class="col-md-3 col-sm-6 text-center">
        <a href="#" id="setView1">
          <div class="card">
            <div class="row">
              <div class="col-12">
                <i class="fad fa-user"></i>
              </div>
              <div class="col-12">
                <h5>Account Information</h5>
              </div>
            </div>
          </div>
        </a>
      </div>
      <div class="col-md-3 col-sm-6 text-center">
        <a href="#" id="setView2">
          <div class="card">
            <div class="row">
              <div class="col-12">
                <i class="fad fa-address-book"></i>
              </div>
              <div class="col-12">
                <h5>Contact Information</h5>
              </div>
            </div>
          </div>
        </a>
      </div>
      <div class="col-md-3 col-sm-6 text-center">
        <a href="#" id="setView3">
          <div class="card">
            <div class="row">
              <div class="col-12">
                <i class="fad fa-map-marker-alt"></i>
              </div>
              <div class="col-12">
                <h5>Billing Information</h5>
              </div>
            </div>
          </div>
        </a>
      </div>
      <div class="col-md-3 col-sm-6 text-center">
        <a href="#" id="setView4">
          <div class="card">
            <div class="row">
              <div class="col-12">
                <i class="far fa-map-marker-alt"></i>
              </div>
              <div class="col-12">
                <h5>Shipping Information</h5>
              </div>
            </div>
          </div>
        </a>
      </div>
      <div class="col-md-3 col-sm-6 text-center">
        <a href="myorders.php">
          <div class="card">
            <div class="row">
              <div class="col-12">
                <i class="fad fa-bags-shopping"></i>
              </div>
              <div class="col-12">
                <h5>Your Orders</h5>
              </div>
            </div>
          </div>
        </a>
      </div>
      <!-- <div class="col-md-3 col-sm-6 text-center">
        <a href="myorders.php">
          <div class="card">
            <div class="row">
              <div class="col-12">
                <i class="fad fa-credit-card"></i>
              </div>
              <div class="col-12">
                <h5>Payment Options</h5>
              </div>
            </div>
          </div>
        </a>
      </div> -->
  </div>

  <div class="card2">
    <div class="set1">
    <h4 class="text_brown"><i class="fad fa-user"></i> &nbsp; Account Information</h4><br>
    <div class="row">
      <div class="col-sm-6">
        <div class="form-group">
          <label>Username</label>
          <input type="text" name="usernmae" value="DheeraR" class="form-control" readonly>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="form-group">
          <label>Email Address</label>
          <input type="email" name="emailID" value="test@gmail.com" class="form-control" readonly>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="form-group">
          <label>First Name</label>
          <input type="text" name="firstname" value="Dheera" class="form-control">
        </div>
      </div>
      <div class="col-sm-6">
        <div class="form-group">
          <label>Last Name</label>
          <input type="text" name="firstname" value="R" class="form-control">
        </div>
      </div>
    </div>


    <hr>
  </div>

  <div class="set2" style="display:none">
     <h4 class="text_brown"><i class="fad fa-address-book"></i> &nbsp; Contact Information</h4><br>

     <div class="row">
      <div class="col-sm-6">
        <div class="form-group">
          <label>Email Address</label>
          <input type="email" name="firstname" value="" class="form-control">
        </div>
      </div>
      <div class="col-sm-6">
        <div class="form-group">
          <label>Phone Number</label>
          <input type="text" name="firstname" value="" class="form-control"> <br>
          <label>Alternative Phone Number</label>
          <input type="text" name="firstname" value="" class="form-control">
        </div>
      </div>
    </div>

    <hr>

  </div>

  <div class="set3" style="display:none">
     <h4 class="text_brown"><i class="fad fa-map-marker-alt"></i> Billing Address</h4><br>
     <div class="row">
      <div class="col-sm-6">
         <div class="form-group">
            <label>Address Line 1 </label>
            <input type="text" class="form-control" placeholder="House number and street name" required />
          </div>
      </div>
      <div class="col-sm-6">
         <div class="form-group">
            <label>Address Line 2 </label>
            <input type="text" class="form-control" placeholder="Apartment, suite, unit, etc. (optional)" required />
          </div>
      </div>
      <div class="col-sm-6">
         <div class="form-group">
            <label>Town / City </label>
            <input type="text" class="form-control" required />
        </div>     
      </div>
      <div class="col-sm-6">
         <div class="form-group">
            <label>State <span class="required">*</span></label>
            <input type="text" class="form-control" required />
          </div>
      </div>
        <div class="col-sm-6">
          <div class="form-group mb-3">
            <label>Country</label>
            <?php include('professionals/common/countryvalue.php')  ?>
          </div>
        </div>
        <div class="col-md-6">
            <div class="form-group mb-3">
              <label>Zip Code</label>
              <input type="text" name="zipcode" class="form-control">
            </div>
        </div>
      </div>


      <hr>
    </div>

    <div class="set4" style="display:none">
     <h4 class="text_brown"><i class="far fa-map-marker-alt"></i> Shipping Address</h4><br>
     <div class="row">
      <div class="col-sm-6">
         <div class="form-group">
            <label>Address Line 1 </label>
            <input type="text" class="form-control" placeholder="House number and street name" required />
          </div>
      </div>
      <div class="col-sm-6">
         <div class="form-group">
            <label>Address Line 2 </label>
            <input type="text" class="form-control" placeholder="Apartment, suite, unit, etc. (optional)" required />
          </div>
      </div>
      <div class="col-sm-6">
         <div class="form-group">
            <label>Town / City </label>
            <input type="text" class="form-control" required />
        </div>     
      </div>
      <div class="col-sm-6">
         <div class="form-group">
            <label>State <span class="required">*</span></label>
            <input type="text" class="form-control" required />
          </div>
      </div>
        <div class="col-sm-6">
          <div class="form-group mb-3">
            <label>Country</label>
            <?php include('professionals/common/countryvalue.php')  ?>
          </div>
        </div>
        <div class="col-md-6">
            <div class="form-group mb-3">
              <label>Zip Code</label>
              <input type="text" name="zipcode" class="form-control">
            </div>
        </div>
      </div>

</div>

  <div class="text-center mt-5 mb-5">
    <button class="btn btn-success btn-lg">Update your profile</button>
  </div>
  </div>


      </div>
</section>


<script type="text/javascript">
  $('#setView1').click(function(){
    $(".set1").show();
    $(".set2").hide();
    $(".set3").hide();
    $(".set4").hide();
});
  $('#setView2').click(function(){
    $(".set1").hide();
    $(".set2").show();
    $(".set3").hide();
    $(".set4").hide();
});
  $('#setView3').click(function(){
    $(".set1").hide();
    $(".set2").hide();
    $(".set3").show();
    $(".set4").hide();
});
  $('#setView4').click(function(){
    $(".set1").hide();
    $(".set2").hide();
    $(".set3").hide();
    $(".set4").show();
});

</script>


<?php include('common/footer.php') ?>