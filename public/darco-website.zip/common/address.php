<div class="row">
        <div class="col-sm-6">
          <div class="form-group">
            <label>First Name <span class="asterisk">*</span></label>
            <input type="text" name="firstname" value="" class="form-control" required>
          </div>
        </div>
        <div class="col-sm-6"> 
          <div class="form-group">
            <label>Last Name <span class="asterisk">*</span></label>
            <input type="text" name="lastname" value="" class="form-control" required>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-12">
          <div class="form-group">
            <label>Country <span class="asterisk">*</span></label>
            <?php include('professionals/common/countryvalue.php')  ?>
          </div>
        </div>
        <div class="col-sm-12">
          <div class="form-group">
            <label>Street address <span class="asterisk">*</span></label>
            <input type="text" name="addressline1" class="form-control" placeholder="Door No., Street address"> <br>
            <input type="text" name="addressline2" class="form-control" placeholder="Apartment, suite (optional)">
          </div>
        </div>
        <div class="col-sm-12">
          <div class="form-group">
            <label>Town / City <span class="asterisk">*</span></label>
            <input type="text" name="city" class="form-control">
          </div>
        </div>
        <div class="col-sm-12">
          <div class="form-group">
            <label>Pincode <span class="asterisk">*</span></label>
            <input type="text" name="pincode" class="form-control">
          </div>
        </div>
      </div>