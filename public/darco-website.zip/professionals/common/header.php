<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="assets/images/ico.ico">
    <title>Darco</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v5.15.4/css/all.css" crossorigin="anonymous" />
    <link rel="stylesheet" href="../assets/css/all.css">   
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">

    <script type="text/javascript" src="../assets/js/jquery.min.js"></script>  
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
  </head>
  <body>

<header class="bd-navbar">

<div class="container-fluid1">
<div class="row">
  <div class="col-md-12 col-lg-2 col-xl-2 text-center" style="padding-right:0">
    <a class="navbar-brand" href="../index.php">
      <img src="../assets/images/logobig.png" width="100">
    </a>
  </div>
  <div class="col-md-12 col-lg-10 col-xl-10" style="padding-left: 0;">
    <?php include('topheader.php') ?>
    </div>
</div>
    <nav class="navbar navbar-expand-xl navbar-dark  bg-light">
  <div class="container-fluid">
  <!-- <div class="toggle-button">
  <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#menu01" aria-controls="menu01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
</div> -->
<!-- To show dropdwon arrow bootstrap file line no : 3017  -->
    <div class="collapse navbar-collapse justify-content-center" id="menu01">
      <ul class="navbar-nav">
        <li class="nav-item dropdown position-static2">
        <a class="nav-link dropdown-toggle smallDropdown main_link" href="#" data-toggle="dropdown" aria-expanded="false"><i class="fas fa-lightbulb"></i> GET IDEAS</a>
        <div class="dropdown-menu" >
          <a class="dropdown-item" href="#">Kitchen & Dining</a>
          <a class="dropdown-item" href="#">Living room</a>
          <a class="dropdown-item" href="#">Bed & Bath</a>
          <a class="dropdown-item" href="#">Utility</a>
          <a class="dropdown-item" href="#">Outdoor</a>
          <a class="dropdown-item" href="#">Bar & Wine</a>
          <a class="dropdown-item" href="#">Popular Design Ideas</a>
        </div>
      </li>
        <li class="nav-item dropdown position-static"><a href="#" class="nav-link dropdown-toggle main_link" data-toggle="dropdown" data-target="#"><i class="fas fa-user-tie"></i> Find Professionals</a>
          <div class="dropdown-menu w-75 top-auto">
            <div class="container">
              <div class="row w-100">
                <div class="col-sm-6 col-lg-4">
              <h4>Design & Planning</h4>
                <ul>
                  <li><a href="#">House Plan</a></li>
                  <li><a href="#">Architects & Building Designers</a></li>
                  <li><a href="#">Interior Designers</a></li>
                  <li><a href="#">Interior Decorators</a></li>
                  <li><a href="#">Lighting Designers</a></li>
                  <li><a href="#">3D Rendering</a></li>
                  <li><a href="#">Basement Design</a></li>
                  <li><a href="#">Energy-Efficient Homes</a></li>
                </ul>
            </div>
            <div class="col-sm-6 col-lg-4">
              <h4>Construction & Renovation</h4>
                <ul>
                  <li><a href="#">General Contrators</a></li>
                  <li><a href="#">Home Builders</a></li>
                  <li><a href="#">Home Remodeling</a></li>
                  <li><a href="#">Kitchen & Bathroom Remodelers</a></li>
                  <li><a href="#">Basement Remodeling</a></li>
                  <li><a href="#">Green Building</a></li>
                  <li><a href="#">Cabinetry & Cabinet Makers</a></li>
                  <li><a href="#">Window Contractors</a></li>
                  <li><a href="#">Exterior & Siding Contractors</a></li>
                  <li><a href="#">Roofing & Gutter Contractors</a></li>
                </ul>
            </div>
            <div class="col-sm-6 col-lg-4">
              <h4>Landscaping & Outdoor</h4>
                <ul>
                  <li><a href="#">Landscape Architects</a></li>
                  <li><a href="#">Landscape Contractors</a></li>
                  <li><a href="#">Landscape Construction</a></li>
                  <li><a href="#">Land Clearing</a></li>
                  <li><a href="#">Garden & Landscape Supplies</a></li>
                  <li><a href="#">Spa & Pool</a></li>
                  <li><a href="#">Hot Tub Installation</a></li>
                  <li><a href="#">Fence</a></li>
                  <li><a href="#">Paver Installation</a></li>
                </ul>
            </div>
          </div>
        </div></div>
        </li>
        <li class="nav-item dropdown position-static2">
        <a class="nav-link dropdown-toggle smallDropdown main_link" href="#" data-toggle="dropdown" aria-expanded="false"><i class="fas fa-shopping-bag"></i> Shop by Department</a>
        <div class="dropdown-menu" >
          <a class="dropdown-item" href="#">Furnitures</a>
          <a class="dropdown-item" href="#">Rugs & Decor</a>
          <a class="dropdown-item" href="#">Lighting</a>
          <a class="dropdown-item" href="#">Gardening</a>
          <a class="dropdown-item" href="#">Tiles</a>
          <a class="dropdown-item" href="#">Home Appliances</a>
        </div>
      </li>
      
      
      </ul>
    </div>
    </div>
</nav>
  

</div>
</header>

    