<?php include('common/header.php') ?>


<div class="container mt-5 mb-5" id="Shoppingcart">
   <div class="card2">
    <div class="row">
      <div class="col-sm-8">
        <h3 class="title">New Billing address</h3>
        <p>Please add your new address</p>
      </div>
    </div>

    <div class="row">
      <div class="col-sm-6">
        <div class="form-group">
          <label>First Name</label>
          <input type="text" name="firstname" value="Dheera" class="form-control">
        </div>
      </div>
      <div class="col-sm-6">
        <div class="form-group">
          <label>Last Name</label>
          <input type="text" name="firstname" value="R" class="form-control">
        </div>
      </div>
      <div class="col-sm-6">
        <div class="form-group">
          <label>Email Address</label>
          <input type="email" name="firstname" value="" class="form-control">
        </div>
      </div>
      <div class="col-sm-6">
        <div class="form-group">
          <label>Phone Number</label>
          <input type="text" name="firstname" value="" class="form-control">
        </div>
      </div>
      <div class="col-sm-6">
        <div class="form-group">
          <label>Address line 1</label>
          <input type="text" name="addr1" value="" class="form-control">
        </div>
      </div>
      <div class="col-sm-6">
        <div class="form-group">
          <label>Address line 2</label>
          <input type="text" name="addr2" value="" class="form-control">
        </div>
      </div>
      <div class="col-md-6">
          <div class="form-group mb-3">
            <label>Country</label>
            <?php  include('professionals/common/countryvalue.php') ?>
          </div>
        </div>
        <div class="col-md-6">
            <div class="form-group mb-3">
              <label>City</label>
              <input type="text" name="city" class="form-control">
            </div>
        </div>
            <div class="col-md-6">
            <div class="form-group mb-3">
              <label>State</label>
              <input type="text" name="state" class="form-control">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group mb-3">
              <label>Zip Code</label>
              <input type="text" name="zipcode" class="form-control">
            </div>
        </div>
      </div>

    <div class="text-center">
      <button class="btn btn-success">Submit</button>
    </div>

  </form>

      </div>

</div>

<?php include('common/footer.php') ?>